const String urlLogo =
    "http://200.94.83.175:8899/cotexsaapi/files/logo/logo.png";

const String urlSucursal = "http://200.94.83.175:8899/cotexsaapi/api/sucursal/";

const String urlAlmacen =
    "http://200.94.83.175:8899/cotexsaapi/api/almacen?Sucursal=0";

const String urlAlmacen1 =
    "http://200.94.83.175:8899/cotexsaapi/api/art/subCuenta?Codigo=0&Almacen=1&Sucursal=2&Articulo=3&Subcuenta=4";

const String urlToken = "http://200.94.83.175:889/cotexsaapi/token";

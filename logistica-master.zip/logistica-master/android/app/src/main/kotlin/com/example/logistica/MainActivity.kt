package com.example.logistica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
